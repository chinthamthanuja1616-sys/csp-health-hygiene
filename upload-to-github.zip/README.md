# Health & Hygiene – Community Service Project (SVCN)

## Add your college logo
The SVCN logo is already at `images/logo.png`. To change it, replace that file.

## Publish on GitHub Pages
1. Create a free account at github.com and click New repository (name it e.g. `csp-health-hygiene`, set Public).
2. Click "uploading an existing file" and drag in everything inside this folder (index.html, css, js, images, .nojekyll). Commit.
3. Go to Settings > Pages. Under Source choose "Deploy from a branch", Branch `main`, folder `/ (root)`, then Save.
4. After 1-2 minutes your link appears: https://YOUR-USERNAME.github.io/csp-health-hygiene/
